<?php
/**
 * SITUNEO DIGITAL - Index
 * Entry Point - Redirects to Router
 */

// Use router for all requests
require_once __DIR__ . '/router.php';
